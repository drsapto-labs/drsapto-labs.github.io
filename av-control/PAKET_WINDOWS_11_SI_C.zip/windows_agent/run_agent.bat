@echo off
title AV Master Control - Windows 11 Agent
color 0a
echo ====================================================================
echo   AV MASTER CONTROL - DESKTOP AGENT
echo ====================================================================
echo.
echo Memeriksa runner Python...

set RUNNER=python
where python >nul 2>nul
if %ERRORLEVEL% NEQ 0 (
    where py >nul 2>nul
    if %ERRORLEVEL% equ 0 (
        set RUNNER=py
    ) else (
        echo [ERROR] Python tidak terdeteksi! Silakan jalankan install.bat terlebih dahulu.
        pause
        exit /b 1
    )
)

echo Memulai agent di latar belakang menggunakan %RUNNER%...
echo Layar otomatis diatur Anti-Sleep (tidak akan pernah mati/lock).
echo Hotkey Darurat: F9 (Tampilkan Profil) ^| F10 (Kembali ke Zoom)
echo.

%RUNNER% agent.py

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] Agent terhenti. Jika dependensi belum lengkap, jalankan install.bat terlebih dahulu.
    pause
)
