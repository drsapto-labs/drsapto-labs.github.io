@echo off
color 0b
echo ====================================================================
echo   INSTALLER DEPENDENSI - AV MASTER CONTROL WINDOWS 11
echo ====================================================================
echo.
echo Memeriksa instalasi Python di Windows...

where python >nul 2>nul
if %ERRORLEVEL% equ 0 (
    set PYCMD=python
    goto :INSTALL
)

where py >nul 2>nul
if %ERRORLEVEL% equ 0 (
    set PYCMD=py
    goto :INSTALL
)

echo [PERINGATAN] Python belum terdeteksi di sistem Windows ini!
echo Silakan unduh Python gratis di: https://www.python.org/downloads/
echo (Pastikan centang "Add Python to PATH" saat menginstall)
echo.
pause
exit /b 1

:INSTALL
echo Menggunakan: %PYCMD%
echo Sedang mengunduh dan memasang modul yang dibutuhkan:
echo - paho-mqtt (Komunikasi Cloud Realtime)
echo - pycaw (Kontrol Audio WASAPI Mute Zoom)
echo - keyboard (Hotkey Darurat F9 / F10)
echo - pywin32 (Manajemen Jendela Layar)
echo.

%PYCMD% -m pip install --upgrade pip
%PYCMD% -m pip install -r requirements.txt

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] Gagal memasang beberapa modul. Pastikan koneksi internet aktif.
) else (
    echo.
    echo ====================================================================
    echo [SUKSES] Semua dependensi berhasil dipasang!
    echo Sekarang Anda cukup menjalankan: run_agent.bat
    echo ====================================================================
)

echo.
pause
