@echo off
color 0b
echo ====================================================================
echo   INSTALLER DEPENDENSI - AV MASTER CONTROL WINDOWS 11
echo ====================================================================
echo.

set PYCMD=python
where python >nul 2>nul
if %ERRORLEVEL% equ 0 goto :INSTALL

where py >nul 2>nul
if %ERRORLEVEL% equ 0 (
    set PYCMD=py
    goto :INSTALL
)

echo [PERINGATAN] Python belum terdeteksi di sistem Windows ini!
echo Silakan unduh Python gratis di: https://www.python.org/downloads/
echo (Pastikan centang "Add Python to PATH" saat menginstall)
echo.
pause
exit /b 1

:INSTALL
echo Menggunakan runner: %PYCMD%
echo.
echo [1/3] Memasang modul utama Cloud Realtime (paho-mqtt)...
%PYCMD% -m pip install --user paho-mqtt

echo.
echo [2/3] Memasang modul audio Windows (pycaw)...
%PYCMD% -m pip install --user pycaw comtypes

echo.
echo [3/3] Memasang modul pendukung (keyboard, pywin32)...
%PYCMD% -m pip install --user keyboard pywin32

echo.
echo ====================================================================
echo [SELESAI] Dependensi utama telah terpasang!
echo Sekarang silakan langsung jalankan: run_agent.bat
echo ====================================================================
echo.
pause
