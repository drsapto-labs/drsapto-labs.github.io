PANDUAN PENYIMPANAN FILE MEDIA
==============================

Letakkan file video profil perusahaan Anda di dalam folder ini dengan nama:
profil_perusahaan.mp4

Format yang didukung:
- MP4 (Sangat direkomendasikan, codec H.264 + AAC Audio)
- Resolusi disarankan: 1920x1080 (Full HD)

Catatan:
Jika nama file berbeda, Anda dapat mengubah nama filenya menjadi "profil_perusahaan.mp4",
atau mengedit baris source di dalam file "player.html".
